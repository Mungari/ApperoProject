package com.example.jonny.googlemapsdonebyme;

import android.content.Context;
import android.content.res.AssetManager;
import android.renderscript.ScriptGroup;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class webActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web);
        WebView web = (WebView)findViewById(R.id.web);
        Button button = (Button)findViewById(R.id.Home);
        String Valore= getIntent().getStringExtra("Informazioni");


        // elementi contiene il nome del percorso e il link passato dall'Activity di GMaps
        String[] elementi = Valore.split(",");
        String percorso = elementi[0];
        String Link= elementi[1];
        web.getSettings().setJavaScriptEnabled(true);
        web.loadUrl(Link);


    }


}


